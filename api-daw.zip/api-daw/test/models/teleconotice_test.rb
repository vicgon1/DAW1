require "test_helper"

class TeleconoticeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
