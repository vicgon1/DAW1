require "test_helper"

class VeterinarianoticeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
