require "test_helper"

class InformaticanoticeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
