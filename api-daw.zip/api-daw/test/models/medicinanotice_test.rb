require "test_helper"

class MedicinanoticeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
