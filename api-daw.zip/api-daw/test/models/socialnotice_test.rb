require "test_helper"

class SocialnoticeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
