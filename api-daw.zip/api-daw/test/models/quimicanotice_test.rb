require "test_helper"

class QuimicanoticeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
