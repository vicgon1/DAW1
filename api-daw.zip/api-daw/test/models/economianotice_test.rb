require "test_helper"

class EconomianoticeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
