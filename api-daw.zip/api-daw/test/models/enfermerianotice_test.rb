require "test_helper"

class EnfermerianoticeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
