require "test_helper"

class VeterinarianoticesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @veterinarianotice = veterinarianotices(:one)
  end

  test "should get index" do
    get veterinarianotices_url
    assert_response :success
  end

  test "should get new" do
    get new_veterinarianotice_url
    assert_response :success
  end

  test "should create veterinarianotice" do
    assert_difference("Veterinarianotice.count") do
      post veterinarianotices_url, params: { veterinarianotice: { body: @veterinarianotice.body, information: @veterinarianotice.information, title: @veterinarianotice.title } }
    end

    assert_redirected_to veterinarianotice_url(Veterinarianotice.last)
  end

  test "should show veterinarianotice" do
    get veterinarianotice_url(@veterinarianotice)
    assert_response :success
  end

  test "should get edit" do
    get edit_veterinarianotice_url(@veterinarianotice)
    assert_response :success
  end

  test "should update veterinarianotice" do
    patch veterinarianotice_url(@veterinarianotice), params: { veterinarianotice: { body: @veterinarianotice.body, information: @veterinarianotice.information, title: @veterinarianotice.title } }
    assert_redirected_to veterinarianotice_url(@veterinarianotice)
  end

  test "should destroy veterinarianotice" do
    assert_difference("Veterinarianotice.count", -1) do
      delete veterinarianotice_url(@veterinarianotice)
    end

    assert_redirected_to veterinarianotices_url
  end
end
