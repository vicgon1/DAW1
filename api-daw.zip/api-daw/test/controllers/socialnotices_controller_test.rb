require "test_helper"

class SocialnoticesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @socialnotice = socialnotices(:one)
  end

  test "should get index" do
    get socialnotices_url
    assert_response :success
  end

  test "should get new" do
    get new_socialnotice_url
    assert_response :success
  end

  test "should create socialnotice" do
    assert_difference("Socialnotice.count") do
      post socialnotices_url, params: { socialnotice: { body: @socialnotice.body, information: @socialnotice.information, title: @socialnotice.title } }
    end

    assert_redirected_to socialnotice_url(Socialnotice.last)
  end

  test "should show socialnotice" do
    get socialnotice_url(@socialnotice)
    assert_response :success
  end

  test "should get edit" do
    get edit_socialnotice_url(@socialnotice)
    assert_response :success
  end

  test "should update socialnotice" do
    patch socialnotice_url(@socialnotice), params: { socialnotice: { body: @socialnotice.body, information: @socialnotice.information, title: @socialnotice.title } }
    assert_redirected_to socialnotice_url(@socialnotice)
  end

  test "should destroy socialnotice" do
    assert_difference("Socialnotice.count", -1) do
      delete socialnotice_url(@socialnotice)
    end

    assert_redirected_to socialnotices_url
  end
end
