require "test_helper"

class MedicinanoticesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @medicinanotice = medicinanotices(:one)
  end

  test "should get index" do
    get medicinanotices_url
    assert_response :success
  end

  test "should get new" do
    get new_medicinanotice_url
    assert_response :success
  end

  test "should create medicinanotice" do
    assert_difference("Medicinanotice.count") do
      post medicinanotices_url, params: { medicinanotice: { body: @medicinanotice.body, information: @medicinanotice.information, title: @medicinanotice.title } }
    end

    assert_redirected_to medicinanotice_url(Medicinanotice.last)
  end

  test "should show medicinanotice" do
    get medicinanotice_url(@medicinanotice)
    assert_response :success
  end

  test "should get edit" do
    get edit_medicinanotice_url(@medicinanotice)
    assert_response :success
  end

  test "should update medicinanotice" do
    patch medicinanotice_url(@medicinanotice), params: { medicinanotice: { body: @medicinanotice.body, information: @medicinanotice.information, title: @medicinanotice.title } }
    assert_redirected_to medicinanotice_url(@medicinanotice)
  end

  test "should destroy medicinanotice" do
    assert_difference("Medicinanotice.count", -1) do
      delete medicinanotice_url(@medicinanotice)
    end

    assert_redirected_to medicinanotices_url
  end
end
