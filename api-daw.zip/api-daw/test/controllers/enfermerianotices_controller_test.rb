require "test_helper"

class EnfermerianoticesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @enfermerianotice = enfermerianotices(:one)
  end

  test "should get index" do
    get enfermerianotices_url
    assert_response :success
  end

  test "should get new" do
    get new_enfermerianotice_url
    assert_response :success
  end

  test "should create enfermerianotice" do
    assert_difference("Enfermerianotice.count") do
      post enfermerianotices_url, params: { enfermerianotice: { body: @enfermerianotice.body, information: @enfermerianotice.information, title: @enfermerianotice.title } }
    end

    assert_redirected_to enfermerianotice_url(Enfermerianotice.last)
  end

  test "should show enfermerianotice" do
    get enfermerianotice_url(@enfermerianotice)
    assert_response :success
  end

  test "should get edit" do
    get edit_enfermerianotice_url(@enfermerianotice)
    assert_response :success
  end

  test "should update enfermerianotice" do
    patch enfermerianotice_url(@enfermerianotice), params: { enfermerianotice: { body: @enfermerianotice.body, information: @enfermerianotice.information, title: @enfermerianotice.title } }
    assert_redirected_to enfermerianotice_url(@enfermerianotice)
  end

  test "should destroy enfermerianotice" do
    assert_difference("Enfermerianotice.count", -1) do
      delete enfermerianotice_url(@enfermerianotice)
    end

    assert_redirected_to enfermerianotices_url
  end
end
