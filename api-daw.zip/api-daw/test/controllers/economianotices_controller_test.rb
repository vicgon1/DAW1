require "test_helper"

class EconomianoticesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @economianotice = economianotices(:one)
  end

  test "should get index" do
    get economianotices_url
    assert_response :success
  end

  test "should get new" do
    get new_economianotice_url
    assert_response :success
  end

  test "should create economianotice" do
    assert_difference("Economianotice.count") do
      post economianotices_url, params: { economianotice: { body: @economianotice.body, information: @economianotice.information, title: @economianotice.title } }
    end

    assert_redirected_to economianotice_url(Economianotice.last)
  end

  test "should show economianotice" do
    get economianotice_url(@economianotice)
    assert_response :success
  end

  test "should get edit" do
    get edit_economianotice_url(@economianotice)
    assert_response :success
  end

  test "should update economianotice" do
    patch economianotice_url(@economianotice), params: { economianotice: { body: @economianotice.body, information: @economianotice.information, title: @economianotice.title } }
    assert_redirected_to economianotice_url(@economianotice)
  end

  test "should destroy economianotice" do
    assert_difference("Economianotice.count", -1) do
      delete economianotice_url(@economianotice)
    end

    assert_redirected_to economianotices_url
  end
end
