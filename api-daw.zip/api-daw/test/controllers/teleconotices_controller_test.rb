require "test_helper"

class TeleconoticesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @teleconotice = teleconotices(:one)
  end

  test "should get index" do
    get teleconotices_url
    assert_response :success
  end

  test "should get new" do
    get new_teleconotice_url
    assert_response :success
  end

  test "should create teleconotice" do
    assert_difference("Teleconotice.count") do
      post teleconotices_url, params: { teleconotice: { body: @teleconotice.body, information: @teleconotice.information, title: @teleconotice.title } }
    end

    assert_redirected_to teleconotice_url(Teleconotice.last)
  end

  test "should show teleconotice" do
    get teleconotice_url(@teleconotice)
    assert_response :success
  end

  test "should get edit" do
    get edit_teleconotice_url(@teleconotice)
    assert_response :success
  end

  test "should update teleconotice" do
    patch teleconotice_url(@teleconotice), params: { teleconotice: { body: @teleconotice.body, information: @teleconotice.information, title: @teleconotice.title } }
    assert_redirected_to teleconotice_url(@teleconotice)
  end

  test "should destroy teleconotice" do
    assert_difference("Teleconotice.count", -1) do
      delete teleconotice_url(@teleconotice)
    end

    assert_redirected_to teleconotices_url
  end
end
