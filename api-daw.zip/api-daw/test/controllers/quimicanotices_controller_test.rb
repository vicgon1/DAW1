require "test_helper"

class QuimicanoticesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @quimicanotice = quimicanotices(:one)
  end

  test "should get index" do
    get quimicanotices_url
    assert_response :success
  end

  test "should get new" do
    get new_quimicanotice_url
    assert_response :success
  end

  test "should create quimicanotice" do
    assert_difference("Quimicanotice.count") do
      post quimicanotices_url, params: { quimicanotice: { body: @quimicanotice.body, information: @quimicanotice.information, title: @quimicanotice.title } }
    end

    assert_redirected_to quimicanotice_url(Quimicanotice.last)
  end

  test "should show quimicanotice" do
    get quimicanotice_url(@quimicanotice)
    assert_response :success
  end

  test "should get edit" do
    get edit_quimicanotice_url(@quimicanotice)
    assert_response :success
  end

  test "should update quimicanotice" do
    patch quimicanotice_url(@quimicanotice), params: { quimicanotice: { body: @quimicanotice.body, information: @quimicanotice.information, title: @quimicanotice.title } }
    assert_redirected_to quimicanotice_url(@quimicanotice)
  end

  test "should destroy quimicanotice" do
    assert_difference("Quimicanotice.count", -1) do
      delete quimicanotice_url(@quimicanotice)
    end

    assert_redirected_to quimicanotices_url
  end
end
