require "test_helper"

class InformaticanoticesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @informaticanotice = informaticanotices(:one)
  end

  test "should get index" do
    get informaticanotices_url
    assert_response :success
  end

  test "should get new" do
    get new_informaticanotice_url
    assert_response :success
  end

  test "should create informaticanotice" do
    assert_difference("Informaticanotice.count") do
      post informaticanotices_url, params: { informaticanotice: { body: @informaticanotice.body, information: @informaticanotice.information, title: @informaticanotice.title } }
    end

    assert_redirected_to informaticanotice_url(Informaticanotice.last)
  end

  test "should show informaticanotice" do
    get informaticanotice_url(@informaticanotice)
    assert_response :success
  end

  test "should get edit" do
    get edit_informaticanotice_url(@informaticanotice)
    assert_response :success
  end

  test "should update informaticanotice" do
    patch informaticanotice_url(@informaticanotice), params: { informaticanotice: { body: @informaticanotice.body, information: @informaticanotice.information, title: @informaticanotice.title } }
    assert_redirected_to informaticanotice_url(@informaticanotice)
  end

  test "should destroy informaticanotice" do
    assert_difference("Informaticanotice.count", -1) do
      delete informaticanotice_url(@informaticanotice)
    end

    assert_redirected_to informaticanotices_url
  end
end
