require "test_helper"

class TurismonoticesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @turismonotice = turismonotices(:one)
  end

  test "should get index" do
    get turismonotices_url
    assert_response :success
  end

  test "should get new" do
    get new_turismonotice_url
    assert_response :success
  end

  test "should create turismonotice" do
    assert_difference("Turismonotice.count") do
      post turismonotices_url, params: { turismonotice: { body: @turismonotice.body, information: @turismonotice.information, title: @turismonotice.title } }
    end

    assert_redirected_to turismonotice_url(Turismonotice.last)
  end

  test "should show turismonotice" do
    get turismonotice_url(@turismonotice)
    assert_response :success
  end

  test "should get edit" do
    get edit_turismonotice_url(@turismonotice)
    assert_response :success
  end

  test "should update turismonotice" do
    patch turismonotice_url(@turismonotice), params: { turismonotice: { body: @turismonotice.body, information: @turismonotice.information, title: @turismonotice.title } }
    assert_redirected_to turismonotice_url(@turismonotice)
  end

  test "should destroy turismonotice" do
    assert_difference("Turismonotice.count", -1) do
      delete turismonotice_url(@turismonotice)
    end

    assert_redirected_to turismonotices_url
  end
end
