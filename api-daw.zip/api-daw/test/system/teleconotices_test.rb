require "application_system_test_case"

class TeleconoticesTest < ApplicationSystemTestCase
  setup do
    @teleconotice = teleconotices(:one)
  end

  test "visiting the index" do
    visit teleconotices_url
    assert_selector "h1", text: "Teleconotices"
  end

  test "should create teleconotice" do
    visit teleconotices_url
    click_on "New teleconotice"

    fill_in "Body", with: @teleconotice.body
    fill_in "Information", with: @teleconotice.information
    fill_in "Title", with: @teleconotice.title
    click_on "Create Teleconotice"

    assert_text "Teleconotice was successfully created"
    click_on "Back"
  end

  test "should update Teleconotice" do
    visit teleconotice_url(@teleconotice)
    click_on "Edit this teleconotice", match: :first

    fill_in "Body", with: @teleconotice.body
    fill_in "Information", with: @teleconotice.information
    fill_in "Title", with: @teleconotice.title
    click_on "Update Teleconotice"

    assert_text "Teleconotice was successfully updated"
    click_on "Back"
  end

  test "should destroy Teleconotice" do
    visit teleconotice_url(@teleconotice)
    click_on "Destroy this teleconotice", match: :first

    assert_text "Teleconotice was successfully destroyed"
  end
end
