require "application_system_test_case"

class VeterinarianoticesTest < ApplicationSystemTestCase
  setup do
    @veterinarianotice = veterinarianotices(:one)
  end

  test "visiting the index" do
    visit veterinarianotices_url
    assert_selector "h1", text: "Veterinarianotices"
  end

  test "should create veterinarianotice" do
    visit veterinarianotices_url
    click_on "New veterinarianotice"

    fill_in "Body", with: @veterinarianotice.body
    fill_in "Information", with: @veterinarianotice.information
    fill_in "Title", with: @veterinarianotice.title
    click_on "Create Veterinarianotice"

    assert_text "Veterinarianotice was successfully created"
    click_on "Back"
  end

  test "should update Veterinarianotice" do
    visit veterinarianotice_url(@veterinarianotice)
    click_on "Edit this veterinarianotice", match: :first

    fill_in "Body", with: @veterinarianotice.body
    fill_in "Information", with: @veterinarianotice.information
    fill_in "Title", with: @veterinarianotice.title
    click_on "Update Veterinarianotice"

    assert_text "Veterinarianotice was successfully updated"
    click_on "Back"
  end

  test "should destroy Veterinarianotice" do
    visit veterinarianotice_url(@veterinarianotice)
    click_on "Destroy this veterinarianotice", match: :first

    assert_text "Veterinarianotice was successfully destroyed"
  end
end
