require "application_system_test_case"

class EnfermerianoticesTest < ApplicationSystemTestCase
  setup do
    @enfermerianotice = enfermerianotices(:one)
  end

  test "visiting the index" do
    visit enfermerianotices_url
    assert_selector "h1", text: "Enfermerianotices"
  end

  test "should create enfermerianotice" do
    visit enfermerianotices_url
    click_on "New enfermerianotice"

    fill_in "Body", with: @enfermerianotice.body
    fill_in "Information", with: @enfermerianotice.information
    fill_in "Title", with: @enfermerianotice.title
    click_on "Create Enfermerianotice"

    assert_text "Enfermerianotice was successfully created"
    click_on "Back"
  end

  test "should update Enfermerianotice" do
    visit enfermerianotice_url(@enfermerianotice)
    click_on "Edit this enfermerianotice", match: :first

    fill_in "Body", with: @enfermerianotice.body
    fill_in "Information", with: @enfermerianotice.information
    fill_in "Title", with: @enfermerianotice.title
    click_on "Update Enfermerianotice"

    assert_text "Enfermerianotice was successfully updated"
    click_on "Back"
  end

  test "should destroy Enfermerianotice" do
    visit enfermerianotice_url(@enfermerianotice)
    click_on "Destroy this enfermerianotice", match: :first

    assert_text "Enfermerianotice was successfully destroyed"
  end
end
