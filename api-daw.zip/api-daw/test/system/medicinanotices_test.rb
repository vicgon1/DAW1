require "application_system_test_case"

class MedicinanoticesTest < ApplicationSystemTestCase
  setup do
    @medicinanotice = medicinanotices(:one)
  end

  test "visiting the index" do
    visit medicinanotices_url
    assert_selector "h1", text: "Medicinanotices"
  end

  test "should create medicinanotice" do
    visit medicinanotices_url
    click_on "New medicinanotice"

    fill_in "Body", with: @medicinanotice.body
    fill_in "Information", with: @medicinanotice.information
    fill_in "Title", with: @medicinanotice.title
    click_on "Create Medicinanotice"

    assert_text "Medicinanotice was successfully created"
    click_on "Back"
  end

  test "should update Medicinanotice" do
    visit medicinanotice_url(@medicinanotice)
    click_on "Edit this medicinanotice", match: :first

    fill_in "Body", with: @medicinanotice.body
    fill_in "Information", with: @medicinanotice.information
    fill_in "Title", with: @medicinanotice.title
    click_on "Update Medicinanotice"

    assert_text "Medicinanotice was successfully updated"
    click_on "Back"
  end

  test "should destroy Medicinanotice" do
    visit medicinanotice_url(@medicinanotice)
    click_on "Destroy this medicinanotice", match: :first

    assert_text "Medicinanotice was successfully destroyed"
  end
end
