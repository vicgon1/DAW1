require "application_system_test_case"

class EconomianoticesTest < ApplicationSystemTestCase
  setup do
    @economianotice = economianotices(:one)
  end

  test "visiting the index" do
    visit economianotices_url
    assert_selector "h1", text: "Economianotices"
  end

  test "should create economianotice" do
    visit economianotices_url
    click_on "New economianotice"

    fill_in "Body", with: @economianotice.body
    fill_in "Information", with: @economianotice.information
    fill_in "Title", with: @economianotice.title
    click_on "Create Economianotice"

    assert_text "Economianotice was successfully created"
    click_on "Back"
  end

  test "should update Economianotice" do
    visit economianotice_url(@economianotice)
    click_on "Edit this economianotice", match: :first

    fill_in "Body", with: @economianotice.body
    fill_in "Information", with: @economianotice.information
    fill_in "Title", with: @economianotice.title
    click_on "Update Economianotice"

    assert_text "Economianotice was successfully updated"
    click_on "Back"
  end

  test "should destroy Economianotice" do
    visit economianotice_url(@economianotice)
    click_on "Destroy this economianotice", match: :first

    assert_text "Economianotice was successfully destroyed"
  end
end
