require "application_system_test_case"

class QuimicanoticesTest < ApplicationSystemTestCase
  setup do
    @quimicanotice = quimicanotices(:one)
  end

  test "visiting the index" do
    visit quimicanotices_url
    assert_selector "h1", text: "Quimicanotices"
  end

  test "should create quimicanotice" do
    visit quimicanotices_url
    click_on "New quimicanotice"

    fill_in "Body", with: @quimicanotice.body
    fill_in "Information", with: @quimicanotice.information
    fill_in "Title", with: @quimicanotice.title
    click_on "Create Quimicanotice"

    assert_text "Quimicanotice was successfully created"
    click_on "Back"
  end

  test "should update Quimicanotice" do
    visit quimicanotice_url(@quimicanotice)
    click_on "Edit this quimicanotice", match: :first

    fill_in "Body", with: @quimicanotice.body
    fill_in "Information", with: @quimicanotice.information
    fill_in "Title", with: @quimicanotice.title
    click_on "Update Quimicanotice"

    assert_text "Quimicanotice was successfully updated"
    click_on "Back"
  end

  test "should destroy Quimicanotice" do
    visit quimicanotice_url(@quimicanotice)
    click_on "Destroy this quimicanotice", match: :first

    assert_text "Quimicanotice was successfully destroyed"
  end
end
