require "application_system_test_case"

class TurismonoticesTest < ApplicationSystemTestCase
  setup do
    @turismonotice = turismonotices(:one)
  end

  test "visiting the index" do
    visit turismonotices_url
    assert_selector "h1", text: "Turismonotices"
  end

  test "should create turismonotice" do
    visit turismonotices_url
    click_on "New turismonotice"

    fill_in "Body", with: @turismonotice.body
    fill_in "Information", with: @turismonotice.information
    fill_in "Title", with: @turismonotice.title
    click_on "Create Turismonotice"

    assert_text "Turismonotice was successfully created"
    click_on "Back"
  end

  test "should update Turismonotice" do
    visit turismonotice_url(@turismonotice)
    click_on "Edit this turismonotice", match: :first

    fill_in "Body", with: @turismonotice.body
    fill_in "Information", with: @turismonotice.information
    fill_in "Title", with: @turismonotice.title
    click_on "Update Turismonotice"

    assert_text "Turismonotice was successfully updated"
    click_on "Back"
  end

  test "should destroy Turismonotice" do
    visit turismonotice_url(@turismonotice)
    click_on "Destroy this turismonotice", match: :first

    assert_text "Turismonotice was successfully destroyed"
  end
end
