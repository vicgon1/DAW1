require "application_system_test_case"

class InformaticanoticesTest < ApplicationSystemTestCase
  setup do
    @informaticanotice = informaticanotices(:one)
  end

  test "visiting the index" do
    visit informaticanotices_url
    assert_selector "h1", text: "Informaticanotices"
  end

  test "should create informaticanotice" do
    visit informaticanotices_url
    click_on "New informaticanotice"

    fill_in "Body", with: @informaticanotice.body
    fill_in "Information", with: @informaticanotice.information
    fill_in "Title", with: @informaticanotice.title
    click_on "Create Informaticanotice"

    assert_text "Informaticanotice was successfully created"
    click_on "Back"
  end

  test "should update Informaticanotice" do
    visit informaticanotice_url(@informaticanotice)
    click_on "Edit this informaticanotice", match: :first

    fill_in "Body", with: @informaticanotice.body
    fill_in "Information", with: @informaticanotice.information
    fill_in "Title", with: @informaticanotice.title
    click_on "Update Informaticanotice"

    assert_text "Informaticanotice was successfully updated"
    click_on "Back"
  end

  test "should destroy Informaticanotice" do
    visit informaticanotice_url(@informaticanotice)
    click_on "Destroy this informaticanotice", match: :first

    assert_text "Informaticanotice was successfully destroyed"
  end
end
