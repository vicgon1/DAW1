require "application_system_test_case"

class SocialnoticesTest < ApplicationSystemTestCase
  setup do
    @socialnotice = socialnotices(:one)
  end

  test "visiting the index" do
    visit socialnotices_url
    assert_selector "h1", text: "Socialnotices"
  end

  test "should create socialnotice" do
    visit socialnotices_url
    click_on "New socialnotice"

    fill_in "Body", with: @socialnotice.body
    fill_in "Information", with: @socialnotice.information
    fill_in "Title", with: @socialnotice.title
    click_on "Create Socialnotice"

    assert_text "Socialnotice was successfully created"
    click_on "Back"
  end

  test "should update Socialnotice" do
    visit socialnotice_url(@socialnotice)
    click_on "Edit this socialnotice", match: :first

    fill_in "Body", with: @socialnotice.body
    fill_in "Information", with: @socialnotice.information
    fill_in "Title", with: @socialnotice.title
    click_on "Update Socialnotice"

    assert_text "Socialnotice was successfully updated"
    click_on "Back"
  end

  test "should destroy Socialnotice" do
    visit socialnotice_url(@socialnotice)
    click_on "Destroy this socialnotice", match: :first

    assert_text "Socialnotice was successfully destroyed"
  end
end
