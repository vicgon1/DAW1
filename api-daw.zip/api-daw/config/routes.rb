Rails.application.routes.draw do
  resources :veterinarianotices
  resources :medicinanotices
  resources :enfermerianotices
  resources :economianotices
  resources :turismonotices
  resources :socialnotices
  resources :quimicanotices
  resources :informaticanotices
  resources :teleconotices
  resources :users
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
