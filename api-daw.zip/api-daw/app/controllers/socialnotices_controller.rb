class SocialnoticesController < ApplicationController
  before_action :set_socialnotice, only: %i[ show edit update destroy ]

  # GET /socialnotices or /socialnotices.json
  def index
    @socialnotices = Socialnotice.all
  end

  # GET /socialnotices/1 or /socialnotices/1.json
  def show
  end

  # GET /socialnotices/new
  def new
    @socialnotice = Socialnotice.new
  end

  # GET /socialnotices/1/edit
  def edit
  end

  # POST /socialnotices or /socialnotices.json
  def create
    @socialnotice = Socialnotice.new(socialnotice_params)

    respond_to do |format|
      if @socialnotice.save
        format.html { redirect_to socialnotice_url(@socialnotice), notice: "Socialnotice was successfully created." }
        format.json { render :show, status: :created, location: @socialnotice }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @socialnotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /socialnotices/1 or /socialnotices/1.json
  def update
    respond_to do |format|
      if @socialnotice.update(socialnotice_params)
        format.html { redirect_to socialnotice_url(@socialnotice), notice: "Socialnotice was successfully updated." }
        format.json { render :show, status: :ok, location: @socialnotice }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @socialnotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /socialnotices/1 or /socialnotices/1.json
  def destroy
    @socialnotice.destroy

    respond_to do |format|
      format.html { redirect_to socialnotices_url, notice: "Socialnotice was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_socialnotice
      @socialnotice = Socialnotice.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def socialnotice_params
      params.require(:socialnotice).permit(:title, :body, :information)
    end
end
