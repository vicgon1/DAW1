class EconomianoticesController < ApplicationController
  before_action :set_economianotice, only: %i[ show edit update destroy ]

  # GET /economianotices or /economianotices.json
  def index
    @economianotices = Economianotice.all
  end

  # GET /economianotices/1 or /economianotices/1.json
  def show
  end

  # GET /economianotices/new
  def new
    @economianotice = Economianotice.new
  end

  # GET /economianotices/1/edit
  def edit
  end

  # POST /economianotices or /economianotices.json
  def create
    @economianotice = Economianotice.new(economianotice_params)

    respond_to do |format|
      if @economianotice.save
        format.html { redirect_to economianotice_url(@economianotice), notice: "Economianotice was successfully created." }
        format.json { render :show, status: :created, location: @economianotice }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @economianotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /economianotices/1 or /economianotices/1.json
  def update
    respond_to do |format|
      if @economianotice.update(economianotice_params)
        format.html { redirect_to economianotice_url(@economianotice), notice: "Economianotice was successfully updated." }
        format.json { render :show, status: :ok, location: @economianotice }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @economianotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /economianotices/1 or /economianotices/1.json
  def destroy
    @economianotice.destroy

    respond_to do |format|
      format.html { redirect_to economianotices_url, notice: "Economianotice was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_economianotice
      @economianotice = Economianotice.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def economianotice_params
      params.require(:economianotice).permit(:title, :body, :information)
    end
end
