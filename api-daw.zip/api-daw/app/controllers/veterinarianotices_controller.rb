class VeterinarianoticesController < ApplicationController
  before_action :set_veterinarianotice, only: %i[ show edit update destroy ]

  # GET /veterinarianotices or /veterinarianotices.json
  def index
    @veterinarianotices = Veterinarianotice.all
  end

  # GET /veterinarianotices/1 or /veterinarianotices/1.json
  def show
  end

  # GET /veterinarianotices/new
  def new
    @veterinarianotice = Veterinarianotice.new
  end

  # GET /veterinarianotices/1/edit
  def edit
  end

  # POST /veterinarianotices or /veterinarianotices.json
  def create
    @veterinarianotice = Veterinarianotice.new(veterinarianotice_params)

    respond_to do |format|
      if @veterinarianotice.save
        format.html { redirect_to veterinarianotice_url(@veterinarianotice), notice: "Veterinarianotice was successfully created." }
        format.json { render :show, status: :created, location: @veterinarianotice }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @veterinarianotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /veterinarianotices/1 or /veterinarianotices/1.json
  def update
    respond_to do |format|
      if @veterinarianotice.update(veterinarianotice_params)
        format.html { redirect_to veterinarianotice_url(@veterinarianotice), notice: "Veterinarianotice was successfully updated." }
        format.json { render :show, status: :ok, location: @veterinarianotice }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @veterinarianotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /veterinarianotices/1 or /veterinarianotices/1.json
  def destroy
    @veterinarianotice.destroy

    respond_to do |format|
      format.html { redirect_to veterinarianotices_url, notice: "Veterinarianotice was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_veterinarianotice
      @veterinarianotice = Veterinarianotice.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def veterinarianotice_params
      params.require(:veterinarianotice).permit(:title, :body, :information)
    end
end
