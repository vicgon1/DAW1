class TurismonoticesController < ApplicationController
  before_action :set_turismonotice, only: %i[ show edit update destroy ]

  # GET /turismonotices or /turismonotices.json
  def index
    @turismonotices = Turismonotice.all
  end

  # GET /turismonotices/1 or /turismonotices/1.json
  def show
  end

  # GET /turismonotices/new
  def new
    @turismonotice = Turismonotice.new
  end

  # GET /turismonotices/1/edit
  def edit
  end

  # POST /turismonotices or /turismonotices.json
  def create
    @turismonotice = Turismonotice.new(turismonotice_params)

    respond_to do |format|
      if @turismonotice.save
        format.html { redirect_to turismonotice_url(@turismonotice), notice: "Turismonotice was successfully created." }
        format.json { render :show, status: :created, location: @turismonotice }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @turismonotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /turismonotices/1 or /turismonotices/1.json
  def update
    respond_to do |format|
      if @turismonotice.update(turismonotice_params)
        format.html { redirect_to turismonotice_url(@turismonotice), notice: "Turismonotice was successfully updated." }
        format.json { render :show, status: :ok, location: @turismonotice }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @turismonotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /turismonotices/1 or /turismonotices/1.json
  def destroy
    @turismonotice.destroy

    respond_to do |format|
      format.html { redirect_to turismonotices_url, notice: "Turismonotice was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_turismonotice
      @turismonotice = Turismonotice.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def turismonotice_params
      params.require(:turismonotice).permit(:title, :body, :information)
    end
end
