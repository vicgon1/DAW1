class InformaticanoticesController < ApplicationController
  before_action :set_informaticanotice, only: %i[ show edit update destroy ]

  # GET /informaticanotices or /informaticanotices.json
  def index
    @informaticanotices = Informaticanotice.all
  end

  # GET /informaticanotices/1 or /informaticanotices/1.json
  def show
  end

  # GET /informaticanotices/new
  def new
    @informaticanotice = Informaticanotice.new
  end

  # GET /informaticanotices/1/edit
  def edit
  end

  # POST /informaticanotices or /informaticanotices.json
  def create
    @informaticanotice = Informaticanotice.new(informaticanotice_params)

    respond_to do |format|
      if @informaticanotice.save
        format.html { redirect_to informaticanotice_url(@informaticanotice), notice: "Informaticanotice was successfully created." }
        format.json { render :show, status: :created, location: @informaticanotice }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @informaticanotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /informaticanotices/1 or /informaticanotices/1.json
  def update
    respond_to do |format|
      if @informaticanotice.update(informaticanotice_params)
        format.html { redirect_to informaticanotice_url(@informaticanotice), notice: "Informaticanotice was successfully updated." }
        format.json { render :show, status: :ok, location: @informaticanotice }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @informaticanotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /informaticanotices/1 or /informaticanotices/1.json
  def destroy
    @informaticanotice.destroy

    respond_to do |format|
      format.html { redirect_to informaticanotices_url, notice: "Informaticanotice was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_informaticanotice
      @informaticanotice = Informaticanotice.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def informaticanotice_params
      params.require(:informaticanotice).permit(:title, :body, :information)
    end
end
