class QuimicanoticesController < ApplicationController
  before_action :set_quimicanotice, only: %i[ show edit update destroy ]

  # GET /quimicanotices or /quimicanotices.json
  def index
    @quimicanotices = Quimicanotice.all
  end

  # GET /quimicanotices/1 or /quimicanotices/1.json
  def show
  end

  # GET /quimicanotices/new
  def new
    @quimicanotice = Quimicanotice.new
  end

  # GET /quimicanotices/1/edit
  def edit
  end

  # POST /quimicanotices or /quimicanotices.json
  def create
    @quimicanotice = Quimicanotice.new(quimicanotice_params)

    respond_to do |format|
      if @quimicanotice.save
        format.html { redirect_to quimicanotice_url(@quimicanotice), notice: "Quimicanotice was successfully created." }
        format.json { render :show, status: :created, location: @quimicanotice }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @quimicanotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /quimicanotices/1 or /quimicanotices/1.json
  def update
    respond_to do |format|
      if @quimicanotice.update(quimicanotice_params)
        format.html { redirect_to quimicanotice_url(@quimicanotice), notice: "Quimicanotice was successfully updated." }
        format.json { render :show, status: :ok, location: @quimicanotice }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @quimicanotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /quimicanotices/1 or /quimicanotices/1.json
  def destroy
    @quimicanotice.destroy

    respond_to do |format|
      format.html { redirect_to quimicanotices_url, notice: "Quimicanotice was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_quimicanotice
      @quimicanotice = Quimicanotice.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def quimicanotice_params
      params.require(:quimicanotice).permit(:title, :body, :information)
    end
end
