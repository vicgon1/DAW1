class EnfermerianoticesController < ApplicationController
  before_action :set_enfermerianotice, only: %i[ show edit update destroy ]

  # GET /enfermerianotices or /enfermerianotices.json
  def index
    @enfermerianotices = Enfermerianotice.all
  end

  # GET /enfermerianotices/1 or /enfermerianotices/1.json
  def show
  end

  # GET /enfermerianotices/new
  def new
    @enfermerianotice = Enfermerianotice.new
  end

  # GET /enfermerianotices/1/edit
  def edit
  end

  # POST /enfermerianotices or /enfermerianotices.json
  def create
    @enfermerianotice = Enfermerianotice.new(enfermerianotice_params)

    respond_to do |format|
      if @enfermerianotice.save
        format.html { redirect_to enfermerianotice_url(@enfermerianotice), notice: "Enfermerianotice was successfully created." }
        format.json { render :show, status: :created, location: @enfermerianotice }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @enfermerianotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /enfermerianotices/1 or /enfermerianotices/1.json
  def update
    respond_to do |format|
      if @enfermerianotice.update(enfermerianotice_params)
        format.html { redirect_to enfermerianotice_url(@enfermerianotice), notice: "Enfermerianotice was successfully updated." }
        format.json { render :show, status: :ok, location: @enfermerianotice }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @enfermerianotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /enfermerianotices/1 or /enfermerianotices/1.json
  def destroy
    @enfermerianotice.destroy

    respond_to do |format|
      format.html { redirect_to enfermerianotices_url, notice: "Enfermerianotice was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_enfermerianotice
      @enfermerianotice = Enfermerianotice.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def enfermerianotice_params
      params.require(:enfermerianotice).permit(:title, :body, :information)
    end
end
