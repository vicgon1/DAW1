class MedicinanoticesController < ApplicationController
  before_action :set_medicinanotice, only: %i[ show edit update destroy ]

  # GET /medicinanotices or /medicinanotices.json
  def index
    @medicinanotices = Medicinanotice.all
  end

  # GET /medicinanotices/1 or /medicinanotices/1.json
  def show
  end

  # GET /medicinanotices/new
  def new
    @medicinanotice = Medicinanotice.new
  end

  # GET /medicinanotices/1/edit
  def edit
  end

  # POST /medicinanotices or /medicinanotices.json
  def create
    @medicinanotice = Medicinanotice.new(medicinanotice_params)

    respond_to do |format|
      if @medicinanotice.save
        format.html { redirect_to medicinanotice_url(@medicinanotice), notice: "Medicinanotice was successfully created." }
        format.json { render :show, status: :created, location: @medicinanotice }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @medicinanotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /medicinanotices/1 or /medicinanotices/1.json
  def update
    respond_to do |format|
      if @medicinanotice.update(medicinanotice_params)
        format.html { redirect_to medicinanotice_url(@medicinanotice), notice: "Medicinanotice was successfully updated." }
        format.json { render :show, status: :ok, location: @medicinanotice }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @medicinanotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /medicinanotices/1 or /medicinanotices/1.json
  def destroy
    @medicinanotice.destroy

    respond_to do |format|
      format.html { redirect_to medicinanotices_url, notice: "Medicinanotice was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_medicinanotice
      @medicinanotice = Medicinanotice.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def medicinanotice_params
      params.require(:medicinanotice).permit(:title, :body, :information)
    end
end
