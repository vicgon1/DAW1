class TeleconoticesController < ApplicationController
  before_action :set_teleconotice, only: %i[ show edit update destroy ]

  # GET /teleconotices or /teleconotices.json
  def index
    @teleconotices = Teleconotice.all
  end

  # GET /teleconotices/1 or /teleconotices/1.json
  def show
  end

  # GET /teleconotices/new
  def new
    @teleconotice = Teleconotice.new
  end

  # GET /teleconotices/1/edit
  def edit
  end

  # POST /teleconotices or /teleconotices.json
  def create
    @teleconotice = Teleconotice.new(teleconotice_params)

    respond_to do |format|
      if @teleconotice.save
        format.html { redirect_to teleconotice_url(@teleconotice), notice: "Teleconotice was successfully created." }
        format.json { render :show, status: :created, location: @teleconotice }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @teleconotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /teleconotices/1 or /teleconotices/1.json
  def update
    respond_to do |format|
      if @teleconotice.update(teleconotice_params)
        format.html { redirect_to teleconotice_url(@teleconotice), notice: "Teleconotice was successfully updated." }
        format.json { render :show, status: :ok, location: @teleconotice }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @teleconotice.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /teleconotices/1 or /teleconotices/1.json
  def destroy
    @teleconotice.destroy

    respond_to do |format|
      format.html { redirect_to teleconotices_url, notice: "Teleconotice was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_teleconotice
      @teleconotice = Teleconotice.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def teleconotice_params
      params.require(:teleconotice).permit(:title, :body, :information)
    end
end
