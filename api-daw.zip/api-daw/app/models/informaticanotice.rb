class Informaticanotice < ApplicationRecord
end
