class Teleconotice < ApplicationRecord
end
