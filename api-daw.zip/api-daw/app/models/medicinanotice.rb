class Medicinanotice < ApplicationRecord
end
