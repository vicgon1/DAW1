class Veterinarianotice < ApplicationRecord
end
