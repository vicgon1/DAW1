class Quimicanotice < ApplicationRecord
end
