class Socialnotice < ApplicationRecord
end
