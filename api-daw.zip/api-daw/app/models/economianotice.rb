class Economianotice < ApplicationRecord
end
