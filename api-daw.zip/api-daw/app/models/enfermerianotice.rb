class Enfermerianotice < ApplicationRecord
end
