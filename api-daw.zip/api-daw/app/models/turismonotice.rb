class Turismonotice < ApplicationRecord
end
